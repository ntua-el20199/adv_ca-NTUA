#!/bin/bash

./plot_mpki_ipc.py 401.bzip2.cslab_branch_preds_train.out 
./plot_mpki_ipc.py 403.gcc.cslab_branch_preds_train.out
./plot_mpki_ipc.py 410.bwaves.cslab_branch_preds_train.out
./plot_mpki_ipc.py 416.gamess.cslab_branch_preds_train.out
./plot_mpki_ipc.py 429.mcf.cslab_branch_preds_train.out
./plot_mpki_ipc.py 433.milc.cslab_branch_preds_train.out
./plot_mpki_ipc.py 435.gromacs.cslab_branch_preds_train.out
./plot_mpki_ipc.py 436.cactusADM.cslab_branch_preds_train.out
./plot_mpki_ipc.py 437.leslie3d.cslab_branch_preds_train.out
./plot_mpki_ipc.py 450.soplex.cslab_branch_preds_train.out
./plot_mpki_ipc.py 456.hmmer.cslab_branch_preds_train.out 
./plot_mpki_ipc.py 459.GemsFDTD.cslab_branch_preds_train.out
./plot_mpki_ipc.py 464.h264ref.cslab_branch_preds_train.out
./plot_mpki_ipc.py 470.lbm.cslab_branch_preds_train.out
./plot_mpki_ipc.py 471.omnetpp.cslab_branch_preds_train.out
./plot_mpki_ipc.py 483.xalancbmk.cslab_branch_preds_train.out